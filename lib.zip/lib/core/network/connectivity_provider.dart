import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../offline/sync_provider.dart';
import '../settings/settings_controller.dart';

final connectivityProvider = Provider<void>((ref) {
  final connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? sub;

  sub = connectivity.onConnectivityChanged.listen((results) {
    final hasConnection =
    results.any((r) => r != ConnectivityResult.none);

    final s = ref.read(settingsProvider);

    if (hasConnection && !s.offlineMode && s.syncEnabled) {
      ref.read(syncEngineProvider).processQueue();
    }
  });

  ref.onDispose(() => sub?.cancel());
});